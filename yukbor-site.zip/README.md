# YukBor

Yuk va transport marketplace: yuk egalari yuk joylaydi, haydovchilar narx taklif qiladi.

## Imkoniyatlar

- Yuklar: qidiruv, filtr, saralash, takliflar, status (Ochiq, Tanlandi, Yo‘lda, Yetkazildi)
- Haydovchilar: mashina turi, sig‘im, yo‘nalish, bo‘sh/band holati
- Ro‘yxatdan o‘tish va kirish (yuk egasi, haydovchi, administrator)
- Yuk egasi va haydovchi kabinetlari
- Admin panel: foydalanuvchilar, yuklar, haydovchilar, xabarlar, sozlamalar

## Fayllar

```
index.html
assets/css/style.css
assets/js/app.js
.nojekyll
```

Server yoki build qadami kerak emas. `index.html` ni brauzerda ochsangiz ishlaydi.

## GitHub Pages orqali joylash

1. GitHub'da yangi repository oching (masalan `yukbor`).
2. Shu papkadagi **hamma fayllarni** repository ildiziga yuklang. `index.html` papka ichida emas, to‘g‘ridan-to‘g‘ri ildizda turishi kerak.
3. Repository sahifasida **Settings → Pages** ga kiring.
4. **Build and deployment → Source** qismida **Deploy from a branch** ni tanlang.
5. **Branch** sifatida `main` va `/ (root)` ni tanlab **Save** bosing.
6. 1–2 daqiqadan keyin sayt shu manzilda ochiladi: `https://<username>.github.io/<repository>/`

`github.com/.../blob/main/index.html` havolasi saytni emas, kodni ko‘rsatadi. Sayt manzili faqat yuqoridagi `github.io` havolasi.

## Demo hisoblar

| Rol | Login | Parol |
| --- | --- | --- |
| Administrator | admin@yukbor.uz | admin123 |
| Yuk egasi | shipper@demo.uz | demo123 |
| Haydovchi | driver@demo.uz | demo123 |

Administrator parolini birinchi kirishda Admin panel → Sozlamalar bo‘limida almashtiring.

## Muhim cheklov

Ma‘lumotlar va hisoblar foydalanuvchi brauzerining `localStorage` xotirasida saqlanadi. Shuning uchun bir qurilmada ro‘yxatdan o‘tgan foydalanuvchini boshqa qurilmada ko‘rib bo‘lmaydi. Parollar xavfsiz serverda emas, brauzerda tekshiriladi, bu faqat namuna uchun.

Haqiqiy ishlaydigan loyiha uchun serverli baza va kirish tizimi kerak (masalan, Supabase). Keyingi bosqich shu bo‘lishi mumkin.
